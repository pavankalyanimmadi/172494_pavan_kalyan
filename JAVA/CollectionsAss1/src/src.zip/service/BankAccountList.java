package service;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import pojo.SavingsAccount;

public class BankAccountList {

	public static void main(String[] args) {
		TreeSet<SavingsAccount> accounts=new TreeSet<>();
		SavingsAccount a1=new SavingsAccount(5000, 555,"XY",true);
		SavingsAccount a2=new SavingsAccount(5000, 222,"AB",true);
		SavingsAccount a3=new SavingsAccount(5000,666,"pQ",true);
		SavingsAccount a4=new SavingsAccount(5000, 444,"kiran",true);
		SavingsAccount a5=new SavingsAccount(5000, 444,"kiran",true);
		
		accounts.add(a1);
		accounts.add(a2);
		accounts.add(a3);
		accounts.add(a4);
		accounts.add(a5);
		
		
		Iterator itr=accounts.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
			
			
		}

	}

}
